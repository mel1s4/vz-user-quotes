<!-- enqueue the wp head -->
<!DOCTYPE html>
<html lang="en">
<head>
  <?php wp_head(); ?>
</head>
<body>
  <div id="root"></div>  <!-- React will be rendered here -->
  <?php wp_footer(); ?>
</body>
</html>

